def handler(event, context):
    print('test')

    return()
